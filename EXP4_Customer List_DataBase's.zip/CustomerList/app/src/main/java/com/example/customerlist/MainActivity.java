package com.example.customerlist;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Step 4.1: made secondLinearLayout global
    LinearLayout secondLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout firstLinearLayout  = new LinearLayout(this);
        secondLinearLayout              = new LinearLayout(this);
        Button addButton                = new Button(this);
        Button webViewButton            = new Button(this);
        ScrollView scrollView           = new ScrollView(this);

        firstLinearLayout.setOrientation(LinearLayout.VERTICAL);
        secondLinearLayout.setOrientation(LinearLayout.VERTICAL);

        // Add Customer Button
        addButton.setText("Add Customer");
        addButton.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        // Open WebView Button
        webViewButton.setText("Open Ritaj");
        webViewButton.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        firstLinearLayout.addView(addButton);
        firstLinearLayout.addView(webViewButton);
        scrollView.addView(secondLinearLayout);
        firstLinearLayout.addView(scrollView);

        setContentView(firstLinearLayout);

        // Add Customer Button Listener
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddCustomerActivity.class);
                MainActivity.this.startActivity(intent);
                finish();
            }
        });

        // WebView Button Listener
        webViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });

        // Step 4.2: removed the old ArrayList loop — display is now handled in onResume
    }

    // Step 4.3: added onResume to load customers from database
    @Override
    protected void onResume() {
        super.onResume();

        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this, "DB_NAME_EXP4", null, 1);
        Cursor allCustomersCursor = dataBaseHelper.getAllCustomers();

        secondLinearLayout.removeAllViews();

        while (allCustomersCursor.moveToNext()) {
            TextView textView = new TextView(MainActivity.this);
            textView.setText(
                    "Id= "     + allCustomersCursor.getString(0) +
                            "\nName= "  + allCustomersCursor.getString(1) +
                            "\nPhone= " + allCustomersCursor.getString(2) +
                            "\nGender= "+ allCustomersCursor.getString(3) +
                            "\n\n"
            );
            secondLinearLayout.addView(textView);
        }
    }
}