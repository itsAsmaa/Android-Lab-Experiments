package com.example.intentsandnotifications;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class MainActivity extends AppCompatActivity {

    // ── Constants ──────────────────────────────────────────────
    private static final String MY_CHANNEL_ID   = "my_channel_1";
    private static final String MY_CHANNEL_NAME = "My Channel";
    private static final int    NOTIFICATION_ID  = 123;

    private static final String NOTIFICATION_TITLE = "Notification Title";
    private static final String NOTIFICATION_BODY  = "This is the body of my notification";
    private static final String TOAST_TEXT         = "This is my toast message";

    // ── onCreate ───────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Request notification permission on Android 13+
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1
            );
        }

        // Find all five buttons
        Button dialButton         = findViewById(R.id.button_dial);
        Button gmailButton        = findViewById(R.id.button_gmail);
        Button mapsButton         = findViewById(R.id.button_maps);
        Button notificationButton = findViewById(R.id.button_notification);
        Button toastButton        = findViewById(R.id.button_toast);

        // ── Dial ──────────────────────────────────────────────
        dialButton.setOnClickListener(view -> {
            Intent dialIntent = new Intent();
            dialIntent.setAction(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:+9725"));
            startActivity(dialIntent);
        });

        // ── Gmail ─────────────────────────────────────────────
        gmailButton.setOnClickListener(view -> {
            Intent gmailIntent = new Intent();
            gmailIntent.setAction(Intent.ACTION_SENDTO);
            gmailIntent.setType("message/rfc822");
            gmailIntent.setData(Uri.parse("mailto:"));
            gmailIntent.putExtra(Intent.EXTRA_EMAIL,   new String[]{"your.email@gmail.com"});
            gmailIntent.putExtra(Intent.EXTRA_SUBJECT, "My Subject");
            gmailIntent.putExtra(Intent.EXTRA_TEXT,    "Content of the message");
            startActivity(gmailIntent);
        });

        // ── Maps ──────────────────────────────────────────────
        mapsButton.setOnClickListener(view -> {
            Intent mapsIntent = new Intent();
            mapsIntent.setAction(Intent.ACTION_VIEW);
            mapsIntent.setData(Uri.parse("geo:19.076,72.8777"));
            startActivity(mapsIntent);
        });

        // ── Notification ──────────────────────────────────────
        notificationButton.setOnClickListener(view ->
                createNotification(NOTIFICATION_TITLE, NOTIFICATION_BODY)
        );

        // ── Toast ─────────────────────────────────────────────
        toastButton.setOnClickListener(view -> {
            Toast toast = Toast.makeText(MainActivity.this, TOAST_TEXT, Toast.LENGTH_SHORT);
            toast.show();
        });
    }

    // ── Create notification channel ────────────────────────────
    private void createNotificationChannel() {
        int importance = NotificationManager.IMPORTANCE_DEFAULT;
        NotificationChannel channel =
                new NotificationChannel(MY_CHANNEL_ID, MY_CHANNEL_NAME, importance);

        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    // ── Create and post notification ───────────────────────────
    public void createNotification(String title, String body) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        );

        createNotificationChannel();

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, MY_CHANNEL_ID)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true);

        NotificationManagerCompat notificationManager =
                NotificationManagerCompat.from(this);

        // try-catch handles the case where user denies notification permission
        try {
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }
}