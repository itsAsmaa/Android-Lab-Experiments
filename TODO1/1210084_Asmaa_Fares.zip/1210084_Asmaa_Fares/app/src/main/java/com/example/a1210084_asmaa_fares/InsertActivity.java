package com.example.a1210084_asmaa_fares;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InsertActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        EditText etKey = (EditText) findViewById(R.id.etKey);
        EditText etVal = (EditText) findViewById(R.id.etVal);
        Button btnSubmit = (Button) findViewById(R.id.btnSubmit);
        Button btnBack = (Button) findViewById(R.id.btnBack);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String k = etKey.getText().toString();
                String val = etVal.getText().toString();

                if (k.isEmpty() || val.isEmpty()) {
                    Toast.makeText(InsertActivity.this, "fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int key = Integer.parseInt(k);
                HashTable.insert(key, val);

                Toast.makeText(InsertActivity.this,
                        "added to bucket " + HashTable.getIndex(key),
                        Toast.LENGTH_SHORT).show();

                startActivity(new Intent(InsertActivity.this, MainActivity.class));
                finish();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(InsertActivity.this, MainActivity.class));
                finish();
            }
        });
    }
}