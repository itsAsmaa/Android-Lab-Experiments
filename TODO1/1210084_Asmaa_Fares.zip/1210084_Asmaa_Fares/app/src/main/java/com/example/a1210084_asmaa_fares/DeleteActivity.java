package com.example.a1210084_asmaa_fares;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DeleteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        EditText etKey = (EditText) findViewById(R.id.etDelKey);
        Button btnDel = (Button) findViewById(R.id.btnDel);
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);
        Button btnReturn = (Button) findViewById(R.id.btnReturn);

        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = etKey.getText().toString();
                if (s.isEmpty()) {
                    tvStatus.setText("enter a key");
                    tvStatus.setTextColor(Color.RED);
                    return;
                }

                int key = Integer.parseInt(s);
                boolean done = HashTable.delete(key);

                if (done) {
                    tvStatus.setText("deleted successfully");
                    tvStatus.setTextColor(Color.parseColor("#4CAF50"));
                    etKey.setText("");
                } else {
                    tvStatus.setText("key not found");
                    tvStatus.setTextColor(Color.RED);
                }
            }
        });

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DeleteActivity.this, MainActivity.class));
                finish();
            }
        });
    }
}