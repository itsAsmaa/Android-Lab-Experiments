package com.example.a1210084_asmaa_fares;

import java.util.ArrayList;

public class HashTable {

    public static Entry[] table = new Entry[4];

    public static int getIndex(int key) {
        return key % 4;
    }

    public static void insert(int key, String val) {
        int i = getIndex(key);
        Entry e = table[i];
        while (e != null) {
            if (e.key == key) {
                e.val = val;
                return;
            }
            e = e.next;
        }
        Entry newE = new Entry(key, val);
        newE.next = table[i];
        table[i] = newE;
    }

    public static boolean delete(int key) {
        int i = getIndex(key);
        Entry curr = table[i];
        Entry prev = null;
        while (curr != null) {
            if (curr.key == key) {
                if (prev == null)
                    table[i] = curr.next;
                else
                    prev.next = curr.next;
                return true;
            }
            prev = curr;
            curr = curr.next;
        }
        return false;
    }

    public static Entry search(int key) {
        int i = getIndex(key);
        Entry curr = table[i];
        while (curr != null) {
            if (curr.key == key)
                return curr;
            curr = curr.next;
        }
        return null;
    }
}