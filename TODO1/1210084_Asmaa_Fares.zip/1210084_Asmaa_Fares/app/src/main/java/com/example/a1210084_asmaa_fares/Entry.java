package com.example.a1210084_asmaa_fares;

public class Entry {

    int key;
    String val;
    Entry next;

    public Entry(int k, String v) {
        key = k;
        val = v;
        next = null;
    }
}