package com.example.a1210084_asmaa_fares;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int[] colors = {
            Color.parseColor("#2196F3"),
            Color.parseColor("#4CAF50"),
            Color.parseColor("#FF9800"),
            Color.parseColor("#9C27B0")
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnInsert = (Button) findViewById(R.id.btnInsert);
        Button btnDelete = (Button) findViewById(R.id.btnDelete);
        Button btnSearch = (Button) findViewById(R.id.btnSearch);
        EditText etSearch = (EditText) findViewById(R.id.etSearch);
        TextView tvResult = (TextView) findViewById(R.id.tvResult);

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, InsertActivity.class));
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DeleteActivity.class));
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = etSearch.getText().toString();
                if (s.isEmpty()) {
                    tvResult.setText("enter a key first");
                    tvResult.setTextColor(Color.RED);
                    return;
                }
                int key = Integer.parseInt(s);
                Entry res = HashTable.search(key);
                if (res != null) {
                    tvResult.setText("found! value = " + res.val + " in bucket " + HashTable.getIndex(key));
                    tvResult.setTextColor(Color.parseColor("#4CAF50"));
                } else {
                    tvResult.setText("not found");
                    tvResult.setTextColor(Color.RED);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        showTable();
        TextView tvResult = (TextView) findViewById(R.id.tvResult);
        tvResult.setText("");
    }

    void showTable() {
        LinearLayout ll = (LinearLayout) findViewById(R.id.llBuckets);
        ll.removeAllViews();

        for (int i = 0; i < 4; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(8, 8, 8, 8);

            TextView bucketLabel = new TextView(this);
            bucketLabel.setText("Bucket " + i);
            bucketLabel.setTextColor(Color.WHITE);
            bucketLabel.setBackgroundColor(colors[i]);
            bucketLabel.setPadding(16, 16, 16, 16);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(180, 120);
            p.setMargins(0, 0, 10, 0);
            bucketLabel.setLayoutParams(p);
            row.addView(bucketLabel);

            TextView content = new TextView(this);
            content.setTextSize(14);
            content.setPadding(8, 8, 8, 8);

            Entry curr = HashTable.table[i];
            if (curr == null) {
                content.setText("empty");
                content.setTextColor(Color.GRAY);
            } else {
                String txt = "";
                while (curr != null) {
                    txt += "(" + curr.key + ", " + curr.val + ")";
                    if (curr.next != null)
                        txt += " → ";
                    else
                        txt += " → NULL";
                    curr = curr.next;
                }
                content.setText(txt);
            }

            row.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams rowP = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            rowP.setMargins(0, 0, 0, 6);
            row.setLayoutParams(rowP);
            row.addView(content);
            ll.addView(row);
        }
    }
}