package com.example.thezoo_1210084_asmaa_fares;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    private EditText editTextVisitorId;
    private EditText editTextPassword;
    private Button buttonLogin;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextVisitorId = findViewById(R.id.editTextVisitorId);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        databaseHelper = new DatabaseHelper(this);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String visitorId = editTextVisitorId.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                if (visitorId.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Login.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (databaseHelper.checkUser(visitorId, password)) {
                    Intent intent = new Intent(Login.this, Selection.class);
                    intent.putExtra("VISITOR_ID", visitorId);
                    startActivity(intent);
                } else {
                    Toast.makeText(Login.this, "Incorrect visitor id or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}