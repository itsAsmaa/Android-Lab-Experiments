package com.example.thezoo_1210084_asmaa_fares;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ZooDB";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_VISITORS = "visitors";
    private static final String COLUMN_VISITOR_ID = "visitor_id";
    private static final String COLUMN_PASSWORD = "password";

    private static final String TABLE_SELECTIONS = "selections";
    private static final String COLUMN_S_ID = "id";
    private static final String COLUMN_S_VISITOR_ID = "visitor_id";
    private static final String COLUMN_S_ANIMAL = "animal";
    private static final String COLUMN_S_ENVIRONMENT = "environment";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_VISITORS_TABLE = "CREATE TABLE " + TABLE_VISITORS + "("
                + COLUMN_VISITOR_ID + " TEXT PRIMARY KEY,"
                + COLUMN_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_VISITORS_TABLE);

        String CREATE_SELECTIONS_TABLE = "CREATE TABLE " + TABLE_SELECTIONS + "("
                + COLUMN_S_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_S_VISITOR_ID + " TEXT,"
                + COLUMN_S_ANIMAL + " TEXT,"
                + COLUMN_S_ENVIRONMENT + " TEXT" + ")";
        db.execSQL(CREATE_SELECTIONS_TABLE);


        ContentValues values = new ContentValues();
        values.put(COLUMN_VISITOR_ID, "visitor123");
        values.put(COLUMN_PASSWORD, "pass123");
        db.insert(TABLE_VISITORS, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VISITORS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SELECTIONS);
        onCreate(db);
    }

    public boolean checkUser(String visitorId, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_VISITORS, new String[]{COLUMN_VISITOR_ID},
                COLUMN_VISITOR_ID + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{visitorId, password}, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public void saveSelection(String visitorId, String animal, String environment) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_S_VISITOR_ID, visitorId);
        values.put(COLUMN_S_ANIMAL, animal);
        values.put(COLUMN_S_ENVIRONMENT, environment);
        db.insert(TABLE_SELECTIONS, null, values);
    }

    public Cursor getLastSelection(String visitorId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_SELECTIONS, null, COLUMN_S_VISITOR_ID + "=?",
                new String[]{visitorId}, null, null, COLUMN_S_ID + " DESC", "1");
    }
}