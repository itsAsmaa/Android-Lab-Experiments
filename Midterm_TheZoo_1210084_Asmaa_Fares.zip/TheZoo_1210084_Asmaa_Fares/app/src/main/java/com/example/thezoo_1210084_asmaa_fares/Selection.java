package com.example.thezoo_1210084_asmaa_fares;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Selection extends AppCompatActivity {

    private String visitorId;
    private Spinner spinnerAnimal;
    private Spinner spinnerEnvironment;
    private DatabaseHelper databaseHelper;
    private String[] environments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        visitorId = getIntent().getStringExtra("VISITOR_ID");
        TextView textViewWelcome = findViewById(R.id.textViewWelcome);
        if (visitorId != null) {
            textViewWelcome.setText("Welcome " + visitorId);
        }

        spinnerAnimal = findViewById(R.id.spinnerAnimal);
        spinnerEnvironment = findViewById(R.id.spinnerEnvironment);
        Button buttonSave = findViewById(R.id.buttonSave);
        Button buttonSeeAnimation = findViewById(R.id.buttonSeeAnimation);

        databaseHelper = new DatabaseHelper(this);
        environments = getResources().getStringArray(R.array.environments);

        // Custom adapter for environment spinner to handle disabling items
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, environments) {
            @Override
            public boolean isEnabled(int position) {
                String animal = spinnerAnimal.getSelectedItem().toString();
                String env = environments[position];

                if ("Lion".equals(animal) && "Sea".equals(env)) {
                    return false;
                }
                if ("Dolphin".equals(animal) && "Forest".equals(env)) {
                    return false;
                }
                return true;
            }

            @Override
            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if (!isEnabled(position)) {
                    tv.setTextColor(Color.GRAY);
                } else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEnvironment.setAdapter(adapter);

        spinnerAnimal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String animal = parent.getItemAtPosition(position).toString();
                String env = spinnerEnvironment.getSelectedItem().toString();


                ((ArrayAdapter)spinnerEnvironment.getAdapter()).notifyDataSetChanged();


                if ("Lion".equals(animal) && "Sea".equals(env)) {
                    spinnerEnvironment.setSelection(0); // Forest
                } else if ("Dolphin".equals(animal) && "Forest".equals(env)) {
                    spinnerEnvironment.setSelection(1); // Sea
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String animal = spinnerAnimal.getSelectedItem().toString();
                String environment = spinnerEnvironment.getSelectedItem().toString();
                databaseHelper.saveSelection(visitorId, animal, environment);
                Toast.makeText(Selection.this, "Selection saved", Toast.LENGTH_SHORT).show();
            }
        });

        buttonSeeAnimation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Selection.this, Animation.class);
                intent.putExtra("VISITOR_ID", visitorId);
                startActivity(intent);
            }
        });
    }
}
