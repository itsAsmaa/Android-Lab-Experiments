package com.example.thezoo_1210084_asmaa_fares;

import android.database.Cursor;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class Animation extends AppCompatActivity {

    private ImageView imageViewEnvironment;
    private ImageView imageViewAnimal;
    private DatabaseHelper databaseHelper;
    private String visitorId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation);

        imageViewEnvironment = findViewById(R.id.imageViewEnvironment);
        imageViewAnimal = findViewById(R.id.imageViewAnimal);
        databaseHelper = new DatabaseHelper(this);

        visitorId = getIntent().getStringExtra("VISITOR_ID");

        if (visitorId != null) {
            displaySavedSelection(visitorId);
        }
    }

    private void displaySavedSelection(String visitorId) {
        Cursor cursor = databaseHelper.getLastSelection(visitorId);
        if (cursor != null && cursor.moveToFirst()) {
            int animalIndex = cursor.getColumnIndex("animal");
            int envIndex = cursor.getColumnIndex("environment");

            if (animalIndex != -1 && envIndex != -1) {
                String animal = cursor.getString(animalIndex);
                String environment = cursor.getString(envIndex);

                updateUI(animal, environment);
            }
            cursor.close();
        }
    }

    private void updateUI(String animal, String environment) {

        if ("Sea".equalsIgnoreCase(environment)) {
            imageViewEnvironment.setImageResource(R.drawable.sea);
        } else if ("Forest".equalsIgnoreCase(environment)) {
            imageViewEnvironment.setImageResource(R.drawable.forest);
        } else {

            imageViewEnvironment.setImageResource(R.drawable.forest);
        }


        if ("Dolphin".equalsIgnoreCase(animal)) {
            imageViewAnimal.setImageResource(R.drawable.dolphin);
        } else if ("Lion".equalsIgnoreCase(animal)) {
            imageViewAnimal.setImageResource(R.drawable.lion);
        } else if ("Bird".equalsIgnoreCase(animal)) {
            imageViewAnimal.setImageResource(R.drawable.bird);
        }


        android.view.animation.Animation anim = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        anim.setDuration(2000);
        imageViewAnimal.startAnimation(anim);
    }
}