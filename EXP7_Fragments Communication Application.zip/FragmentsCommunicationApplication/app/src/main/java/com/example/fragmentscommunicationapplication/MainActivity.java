package com.example.fragmentscommunicationapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
        implements SecondFragment.communicator {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGoToTransaction = findViewById(R.id.btn_go_to_transaction);
        btnGoToTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TransactionActivity.class);
                startActivity(intent);
            }
        });
    }

    // Step 4: override the respond method to pass data to SecondFragment
    @Override
    public void respond(String data) {
        SecondFragment secondFragment =
                (SecondFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.fragment2);
        if (secondFragment != null) {
            secondFragment.changeData(data);
        }
    }
}