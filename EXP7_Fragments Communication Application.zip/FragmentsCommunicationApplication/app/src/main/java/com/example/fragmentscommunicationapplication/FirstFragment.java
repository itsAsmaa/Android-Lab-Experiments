package com.example.fragmentscommunicationapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FirstFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    // Calling the respond method from the FirstFragment as per PDF section 4.1
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        final SecondFragment.communicator communicator =
                (SecondFragment.communicator) getActivity();

        Button button = (Button) getActivity().findViewById(R.id.button);
        final int[] i = {0};

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i[0]++;
                communicator.respond("the button is clicked " + i[0] + " times");
            }
        });
    }
}