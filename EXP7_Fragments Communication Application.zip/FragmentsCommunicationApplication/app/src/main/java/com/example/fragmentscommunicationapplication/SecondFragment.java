package com.example.fragmentscommunicationapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {

    // Step 1: Define the Interface in the SecondFragment class
    public interface communicator {
        void respond(String data);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    // Step 2: Method to display the data on a Text View
    public void changeData(String data) {
        TextView textView = (TextView) getActivity().findViewById(R.id.textView);
        if (textView != null) {
            textView.setText(data);
        }
    }
}