package com.example.fragmentscommunicationapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class TransactionActivity extends AppCompatActivity {

    private FirstTransactionFragment firstFragment;
    private SecondTransactionFragment secondFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        final FragmentManager fragmentManager = getSupportFragmentManager();

        // Check if fragments already exist in the fragment manager (e.g., after a configuration change)
        firstFragment = (FirstTransactionFragment) fragmentManager.findFragmentByTag("FirstFrag");
        if (firstFragment == null) {
            firstFragment = new FirstTransactionFragment();
        }

        secondFragment = (SecondTransactionFragment) fragmentManager.findFragmentByTag("SecondFrag");
        if (secondFragment == null) {
            secondFragment = new SecondTransactionFragment();
        }

        Button buttonAddF = findViewById(R.id.add_f);
        buttonAddF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft = fragmentManager.beginTransaction();
                boolean changed = false;
                
                // Add first fragment if it's not already in the layout
                if (!firstFragment.isAdded()) {
                    ft.add(R.id.root_layout, firstFragment, "FirstFrag");
                    changed = true;
                }
                
                // Add second fragment if it's not already in the layout
                if (!secondFragment.isAdded()) {
                    ft.add(R.id.root_layout, secondFragment, "SecondFrag");
                    changed = true;
                }
                
                if (changed) {
                    ft.commitNow(); // Using commitNow to ensure immediate state update and prevent double-add crashes
                }
            }
        });

        Button buttonRemoveF = findViewById(R.id.remove_f);
        buttonRemoveF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft = fragmentManager.beginTransaction();
                boolean changed = false;
                
                if (firstFragment.isAdded()) {
                    ft.remove(firstFragment);
                    changed = true;
                }
                if (secondFragment.isAdded()) {
                    ft.remove(secondFragment);
                    changed = true;
                }
                
                if (changed) {
                    ft.commitNow();
                }
            }
        });

        Button buttonReplaceF = findViewById(R.id.replace_f);
        buttonReplaceF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Replace all fragments in root_layout with the second fragment
                fragmentManager.beginTransaction()
                        .replace(R.id.root_layout, secondFragment, "SecondFrag")
                        .commitNow();
            }
        });

        Button buttonAttachF = findViewById(R.id.attach_f);
        buttonAttachF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (firstFragment.isDetached()) {
                    fragmentManager.beginTransaction()
                            .attach(firstFragment)
                            .commitNow();
                }
            }
        });

        Button buttonDetachF = findViewById(R.id.detach_f);
        buttonDetachF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (firstFragment.isAdded() && !firstFragment.isDetached()) {
                    fragmentManager.beginTransaction()
                            .detach(firstFragment)
                            .commitNow();
                }
            }
        });
    }
}
