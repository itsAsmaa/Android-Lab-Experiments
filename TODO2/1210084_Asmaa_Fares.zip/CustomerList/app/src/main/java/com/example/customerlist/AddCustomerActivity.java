package com.example.customerlist;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity for adding a new customer.
 */
public class AddCustomerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_customer);

        // Setup Gender Spinner
        String[] options = {"Male", "Female"};
        final Spinner genderSpinner = (Spinner) findViewById(R.id.spinner_Gender);
        ArrayAdapter<String> objGenderArr = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                options
        );
        genderSpinner.setAdapter(objGenderArr);

        // Find EditTexts
        final EditText idEditText    = (EditText) findViewById(R.id.editText_Id);
        final EditText nameEditText  = (EditText) findViewById(R.id.editText_Name);
        final EditText phoneEditText = (EditText) findViewById(R.id.editText_Phone);

        // Add Customer Button
        Button addCustomerButton = (Button) findViewById(R.id.button_Add_Customer);
        addCustomerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String idStr = idEditText.getText().toString();
                String name = nameEditText.getText().toString();
                String phone = phoneEditText.getText().toString();
                String gender = genderSpinner.getSelectedItem().toString();

                if (idStr.isEmpty() || name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(AddCustomerActivity.this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                long id;
                try {
                    id = Long.parseLong(idStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(AddCustomerActivity.this, "Invalid ID format", Toast.LENGTH_SHORT).show();
                    return;
                }

                Customer newCustomer = new Customer(id, name, phone, gender);

                DataBaseHelper dbHelper = new DataBaseHelper(AddCustomerActivity.this, "DB_NAME_EXP4", null, 1);
                long result = dbHelper.insertCustomer(newCustomer);

                if (result == -1){
                    Toast.makeText(AddCustomerActivity.this, "Customer with this ID already exists", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddCustomerActivity.this, "Customer added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}
