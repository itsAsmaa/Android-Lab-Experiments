package com.example.customerlist;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    LinearLayout secondLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(16, 16, 16, 16);

        Button addButton = new Button(this);
        addButton.setText("Add Customer");

        Button webViewButton = new Button(this);
        webViewButton.setText("Open Ritaj");

        Button deleteAllButton = new Button(this);
        deleteAllButton.setText("Delete All Customers");
        deleteAllButton.setBackgroundColor(Color.RED);
        deleteAllButton.setTextColor(Color.WHITE);

        secondLinearLayout = new LinearLayout(this);
        secondLinearLayout.setOrientation(LinearLayout.VERTICAL);

        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(secondLinearLayout);

        mainLayout.addView(addButton);
        mainLayout.addView(webViewButton);
        mainLayout.addView(deleteAllButton);
        mainLayout.addView(scrollView);

        setContentView(mainLayout);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddCustomerActivity.class);
                startActivity(intent);
            }
        });

        webViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                startActivity(intent);
            }
        });

        deleteAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataBaseHelper dbHelper = new DataBaseHelper(MainActivity.this, "DB_NAME_EXP4", null, 1);
                dbHelper.deleteAllCustomers();
                Toast.makeText(MainActivity.this, "All customers deleted", Toast.LENGTH_SHORT).show();
                refreshCustomerList();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCustomerList();
    }

    private void refreshCustomerList() {
        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this, "DB_NAME_EXP4", null, 1);
        Cursor cursor = dataBaseHelper.getAllCustomers();

        secondLinearLayout.removeAllViews();

        while (cursor.moveToNext()) {
            final long id = cursor.getLong(0);
            String name = cursor.getString(1);
            String phone = cursor.getString(2);
            String gender = cursor.getString(3);

            LinearLayout customerContainer = new LinearLayout(this);
            customerContainer.setOrientation(LinearLayout.VERTICAL);
            customerContainer.setPadding(20, 20, 20, 20);
            customerContainer.setBackgroundColor(Color.LTGRAY);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(0, 0, 0, 16);
            customerContainer.setLayoutParams(params);
            customerContainer.setClickable(true);
            customerContainer.setFocusable(true);

            TextView infoTextView = new TextView(this);
            infoTextView.setText("ID: " + id + "\nName: " + name + "\nPhone: " + phone + "\nGender: " + gender);
            infoTextView.setTextColor(Color.BLACK);
            customerContainer.addView(infoTextView);

            LinearLayout buttonLayout = new LinearLayout(this);
            buttonLayout.setOrientation(LinearLayout.HORIZONTAL);

            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openEditActivity(id);
                }
            });

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DataBaseHelper db = new DataBaseHelper(MainActivity.this, "DB_NAME_EXP4", null, 1);
                    db.deleteCustomer(id);
                    Toast.makeText(MainActivity.this, "Customer deleted successfully", Toast.LENGTH_SHORT).show();
                    refreshCustomerList();
                }
            });

            buttonLayout.addView(editButton);
            buttonLayout.addView(deleteButton);
            customerContainer.addView(buttonLayout);

            customerContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openEditActivity(id);
                }
            });

            secondLinearLayout.addView(customerContainer);
        }
        cursor.close();
    }

    private void openEditActivity(long id) {
        Intent intent = new Intent(MainActivity.this, EditCustomerActivity.class);
        intent.putExtra("CUSTOMER_ID", id);
        startActivity(intent);
    }
}
