package com.example.customerlist;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditCustomerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_customer);

        final EditText idEditText = findViewById(R.id.editText_Id_Edit);
        final EditText nameEditText = findViewById(R.id.editText_Name_Edit);
        final EditText phoneEditText = findViewById(R.id.editText_Phone_Edit);
        final Spinner genderSpinner = findViewById(R.id.spinner_Gender_Edit);
        Button editButton = findViewById(R.id.button_Edit_Customer);

        String[] options = {"Male", "Female"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        genderSpinner.setAdapter(adapter);

        long customerId = getIntent().getLongExtra("CUSTOMER_ID", -1);

        if (customerId != -1) {
            DataBaseHelper dbHelper = new DataBaseHelper(this, "DB_NAME_EXP4", null, 1);
            Cursor cursor = dbHelper.getCustomerById(customerId);
            if (cursor.moveToFirst()) {
                idEditText.setText(String.valueOf(cursor.getLong(0)));
                nameEditText.setText(cursor.getString(1));
                phoneEditText.setText(cursor.getString(2));
                String gender = cursor.getString(3);
                if (gender.equals("Male")) {
                    genderSpinner.setSelection(0);
                } else {
                    genderSpinner.setSelection(1);
                }
            }
            cursor.close();
        }

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String phone = phoneEditText.getText().toString();
                String gender = genderSpinner.getSelectedItem().toString();

                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(EditCustomerActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                Customer customer = new Customer(customerId, name, phone, gender);
                DataBaseHelper dbHelper = new DataBaseHelper(EditCustomerActivity.this, "DB_NAME_EXP4", null, 1);
                int result = dbHelper.updateCustomer(customer);

                if (result > 0) {
                    Toast.makeText(EditCustomerActivity.this, "Customer updated successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(EditCustomerActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(EditCustomerActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
