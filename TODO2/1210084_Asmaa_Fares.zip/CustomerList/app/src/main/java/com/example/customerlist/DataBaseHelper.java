package com.example.customerlist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {

    public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE CUSTOMER(ID LONG PRIMARY KEY, NAME TEXT, PHONE TEXT, GENDER TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }

    public long insertCustomer(Customer customer) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", customer.getmCustomerId());
        contentValues.put("NAME", customer.getmName());
        contentValues.put("PHONE", customer.getmPhone());
        contentValues.put("GENDER", customer.getmGender());
        return db.insert("CUSTOMER", null, contentValues);
    }

    public Cursor getAllCustomers() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM CUSTOMER", null);
    }

    public Cursor getCustomerById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM CUSTOMER WHERE ID = " + id, null);
    }

    public int updateCustomer(Customer customer) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME", customer.getmName());
        contentValues.put("PHONE", customer.getmPhone());
        contentValues.put("GENDER", customer.getmGender());
        return db.update("CUSTOMER", contentValues, "ID = ?", new String[]{String.valueOf(customer.getmCustomerId())});
    }

    public void deleteCustomer(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("CUSTOMER", "ID = ?", new String[]{String.valueOf(id)});
    }

    public void deleteAllCustomers() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("CUSTOMER", null, null);
    }
}
