package com.example.mystudyplanner;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LogFragment extends Fragment {

    private EditText etSubject, etHours;
    private Button btnLog, btnToSummary;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_log, container, false);

        etSubject = view.findViewById(R.id.et_subject);
        etHours = view.findViewById(R.id.et_hours);
        btnLog = view.findViewById(R.id.btn_log_session);
        btnToSummary = view.findViewById(R.id.btn_to_summary);

        SharedPrefManager manager = SharedPrefManager.getInstance(requireContext());

        btnLog.setOnClickListener(v -> {
            String subject = etSubject.getText().toString().trim();
            String hoursStr = etHours.getText().toString().trim();

            if (!subject.isEmpty() && !hoursStr.isEmpty()) {
                float hours = Float.parseFloat(hoursStr);
                manager.logSession(subject, hours);
                Toast.makeText(getContext(), getString(R.string.session_logged, subject), Toast.LENGTH_SHORT).show();
                etSubject.setText("");
                etHours.setText("");
            } else {
                Toast.makeText(getContext(), R.string.fill_all_fields, Toast.LENGTH_SHORT).show();
            }
        });

        btnToSummary.setOnClickListener(v -> {
            ((MainActivity) requireActivity()).navigateTo(new SummaryFragment());
        });

        return view;
    }
}
