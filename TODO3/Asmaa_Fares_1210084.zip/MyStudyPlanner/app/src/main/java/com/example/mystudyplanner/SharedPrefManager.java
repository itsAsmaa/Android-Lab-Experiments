package com.example.mystudyplanner;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Map;

public class SharedPrefManager {
    private static final String PREF_NAME = "MyStudyPlannerPrefs";
    private static final String KEY_NAME = "name";
    private static final String KEY_MAJOR = "major";
    private static final String KEY_DAILY_GOAL = "daily_goal";
    private static final String KEY_IS_PROFILE_SAVED = "is_profile_saved";
    private static final String KEY_TOTAL_SESSIONS = "total_sessions";
    private static final String KEY_TOTAL_HOURS = "total_hours";
    private static final String PREFIX_SUBJECT = "subject_";

    private static SharedPrefManager instance;
    private SharedPreferences sharedPreferences;

    private SharedPrefManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (instance == null) {
            instance = new SharedPrefManager(context.getApplicationContext());
        }
        return instance;
    }

    public void saveProfile(String name, String major, int dailyGoal) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_NAME, name);
        editor.putString(KEY_MAJOR, major);
        editor.putInt(KEY_DAILY_GOAL, dailyGoal);
        editor.putBoolean(KEY_IS_PROFILE_SAVED, true);
        editor.apply();
    }

    public boolean isProfileSaved() {
        return sharedPreferences.getBoolean(KEY_IS_PROFILE_SAVED, false);
    }

    public String getName() {
        return sharedPreferences.getString(KEY_NAME, "");
    }

    public String getMajor() {
        return sharedPreferences.getString(KEY_MAJOR, "");
    }

    public int getDailyGoal() {
        return sharedPreferences.getInt(KEY_DAILY_GOAL, 0);
    }

    public int getTotalSessions() {
        return sharedPreferences.getInt(KEY_TOTAL_SESSIONS, 0);
    }

    public float getTotalHours() {
        return sharedPreferences.getFloat(KEY_TOTAL_HOURS, 0);
    }

    public void logSession(String subject, float hours) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        float subjectHours = sharedPreferences.getFloat(PREFIX_SUBJECT + subject, 0);
        editor.putFloat(PREFIX_SUBJECT + subject, subjectHours + hours);
        
        int sessions = sharedPreferences.getInt(KEY_TOTAL_SESSIONS, 0);
        editor.putInt(KEY_TOTAL_SESSIONS, sessions + 1);
        
        float totalHours = sharedPreferences.getFloat(KEY_TOTAL_HOURS, 0);
        editor.putFloat(KEY_TOTAL_HOURS, totalHours + hours);
        
        editor.apply();
    }

    public Map<String, ?> getAllData() {
        return sharedPreferences.getAll();
    }

    public void resetData() {
        sharedPreferences.edit().clear().apply();
    }
}
