package com.example.mystudyplanner;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private EditText etName, etMajor, etDailyGoal;
    private Button btnSave, btnNext;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        etName = view.findViewById(R.id.et_name);
        etMajor = view.findViewById(R.id.et_major);
        etDailyGoal = view.findViewById(R.id.et_daily_goal);
        btnSave = view.findViewById(R.id.btn_save_profile);
        btnNext = view.findViewById(R.id.btn_next);

        SharedPrefManager manager = SharedPrefManager.getInstance(requireContext());

        if (manager.isProfileSaved()) {
            etName.setText(manager.getName());
            etMajor.setText(manager.getMajor());
            etDailyGoal.setText(String.valueOf(manager.getDailyGoal()));
        }

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String major = etMajor.getText().toString().trim();
            String goalStr = etDailyGoal.getText().toString().trim();

            if (!name.isEmpty() && !major.isEmpty() && !goalStr.isEmpty()) {
                int goal = Integer.parseInt(goalStr);
                manager.saveProfile(name, major, goal);
                Toast.makeText(getContext(), R.string.profile_saved, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        btnNext.setOnClickListener(v -> {
            if (manager.isProfileSaved()) {
                ((MainActivity) requireActivity()).navigateTo(new LogFragment());
            } else {
                Toast.makeText(getContext(), "no profile has been saved yet", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
