package com.example.mystudyplanner;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.Map;

public class SummaryFragment extends Fragment {

    private TextView tvProfileInfo, tvTotals, tvSubjectList;
    private Button btnReset, btnBack;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_summary, container, false);

        tvProfileInfo = view.findViewById(R.id.tv_profile_info);
        tvTotals = view.findViewById(R.id.tv_totals);
        tvSubjectList = view.findViewById(R.id.tv_subject_list);
        btnReset = view.findViewById(R.id.btn_reset);
        btnBack = view.findViewById(R.id.btn_back_to_log);

        SharedPrefManager manager = SharedPrefManager.getInstance(requireContext());

        if (!manager.isProfileSaved()) {
            tvProfileInfo.setText(R.string.no_profile);
            tvTotals.setVisibility(View.GONE);
            tvSubjectList.setVisibility(View.GONE);
        } else {
            displayData(manager);
        }

        btnReset.setOnClickListener(v -> {
            manager.resetData();
            ((MainActivity) requireActivity()).navigateTo(new ProfileFragment());
        });

        btnBack.setOnClickListener(v -> {
            ((MainActivity) requireActivity()).navigateTo(new LogFragment());
        });

        return view;
    }

    private void displayData(SharedPrefManager manager) {
        // Requirement: Student's name, major, daily goal
        String profile = getString(R.string.profile_info_format, 
                manager.getName(), manager.getMajor(), manager.getDailyGoal());
        tvProfileInfo.setText(profile);

        Map<String, ?> allEntries = manager.getAllData();
        StringBuilder subjectsBuilder = new StringBuilder();
        int subjectCount = 0;
        float totalHours = 0;

        // Iterate through entries to find subjects (prefixed with subject_)
        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            if (entry.getKey().startsWith("subject_")) {
                String subjectName = entry.getKey().replace("subject_", "");
                Object value = entry.getValue();
                if (value instanceof Float) {
                    float hours = (Float) value;
                    subjectsBuilder.append(getString(R.string.subject_entry_format, subjectName, hours));
                    subjectCount++;
                    totalHours += hours;
                }
            }
        }

        // Requirement: total subjects, total hours
        tvTotals.setText(getString(R.string.totals_format, subjectCount, totalHours));
        
        // Requirement: each subject with its hours
        tvSubjectList.setText(subjectsBuilder.toString());
    }
}
