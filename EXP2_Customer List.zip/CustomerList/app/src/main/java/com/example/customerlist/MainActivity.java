package com.example.customerlist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout firstLinearLayout  = new LinearLayout(this);
        LinearLayout secondLinearLayout = new LinearLayout(this);
        Button addButton                = new Button(this);
        Button webViewButton            = new Button(this);
        ScrollView scrollView           = new ScrollView(this);

        firstLinearLayout.setOrientation(LinearLayout.VERTICAL);
        secondLinearLayout.setOrientation(LinearLayout.VERTICAL);

        // Add Customer Button
        addButton.setText("Add Customer");
        addButton.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        // Open WebView Button
        webViewButton.setText("Open Ritaj");
        webViewButton.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        firstLinearLayout.addView(addButton);
        firstLinearLayout.addView(webViewButton);
        scrollView.addView(secondLinearLayout);
        firstLinearLayout.addView(scrollView);

        setContentView(firstLinearLayout);

        // Add Customer Button Listener
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddCustomerActivity.class);
                MainActivity.this.startActivity(intent);
                finish();
            }
        });

        // WebView Button Listener
        webViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });

        // Display all customers
        for (Customer objCustomer : Customer.customersArrayList) {
            TextView txtCustomerInfo = new TextView(this);
            txtCustomerInfo.setTextSize(18);
            txtCustomerInfo.setPadding(16, 16, 16, 16);
            txtCustomerInfo.setText(objCustomer.toString());
            secondLinearLayout.addView(txtCustomerInfo);
        }
    }
}